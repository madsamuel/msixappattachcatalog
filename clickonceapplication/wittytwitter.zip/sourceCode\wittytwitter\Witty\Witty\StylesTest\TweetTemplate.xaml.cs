﻿
namespace Witty
{
	public partial class TweetTemplate
	{
		public TweetTemplate()
		{
			this.InitializeComponent();
			
			// Insert code required on object creation below this point.
		}
	}
}