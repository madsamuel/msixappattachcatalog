﻿using System.Net;
using System.Windows;
using log4net;
using TwitterLib;
using System.Windows.Input;
using TweetSharp.Model;

namespace Witty
{
	public partial class LoginControl
    {
		public static RoutedCommand RequestPin = new RoutedCommand();
		public static RoutedCommand SupplyPin = new RoutedCommand();
        public TwitterNet Twitter { get; set; }
        private static readonly ILog logger = LogManager.GetLogger("Witty.Logging");
        private readonly Properties.Settings AppSettings = Properties.Settings.Default;
		public string Pin { get; set; }
		private delegate void LoginDelegate(TwitterNet arg);
        private delegate void PostLoginDelegate(OAuthToken arg);

        public LoginControl()
        {
            this.InitializeComponent();
        }

        private void SupplyPin_Executed(object sender, RoutedEventArgs e)
        {
            // Attempt login in a new thread
            LoginButton.Dispatcher.BeginInvoke(
                System.Windows.Threading.DispatcherPriority.Normal,
                new LoginDelegate(TryLogin), Twitter);
        }

        private void TryLogin(TwitterNet twitter)
        {
            try
            {
                // Schedule the update function in the UI thread.
                LayoutRoot.Dispatcher.BeginInvoke(
                    System.Windows.Threading.DispatcherPriority.Normal,
                    new PostLoginDelegate(UpdatePostLoginInterface), 
                    twitter.Authenticate(pinEdit.Text));
            }
            catch (WebException ex)
            {
                logger.Error("There was a problem logging in Twitter.");
                MessageBox.Show("There was a problem logging in to Twitter. " + ex.Message);
            }
            catch (RateLimitException ex)
            {
                logger.Error("There was a rate limit exception.");
                MessageBox.Show(ex.Message);
            }
            catch (ProxyAuthenticationRequiredException ex)
            {
                logger.Error("Incorrect proxy configuration.");
                MessageBox.Show("Proxy server is configured incorrectly.  Please correct the settings on the Options menu.");
            }
        }

        private void UpdatePostLoginInterface(OAuthToken token)
        {
            App.LoggedInUser = Twitter.Login(token);
            if (App.LoggedInUser != null)
            {
                AppSettings.Username = App.LoggedInUser.ScreenName;
                AppSettings.OAuthToken = token.Token;
                AppSettings.OAuthTokenSecret = token.TokenSecret;
                AppSettings.LastUpdated = string.Empty;

                AppSettings.Save();

                RaiseEvent(new RoutedEventArgs(LoginEvent));
            }
            else
            {
                MessageBox.Show("Incorrect username or password. Please try again");
            }
        }

        public static readonly RoutedEvent LoginEvent =
            EventManager.RegisterRoutedEvent("Login", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(LoginControl));

        public event RoutedEventHandler Login
        {
            add { AddHandler(LoginEvent, value); }
            remove { RemoveHandler(LoginEvent, value); }
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            // Set Username textbox as default focus
            LoginButton.Focus();
        }

		private void RequestPin_Executed(object sender, ExecutedRoutedEventArgs e) {
			Twitter.FetchPin(AppSettings.ConsumerKey, AppSettings.ConsumerSecret);
		}
    }
}
