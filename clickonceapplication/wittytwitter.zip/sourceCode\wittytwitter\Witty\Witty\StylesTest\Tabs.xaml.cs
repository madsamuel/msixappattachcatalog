﻿
namespace Witty
{
	public partial class Tabs
	{
		public Tabs()
		{
			this.InitializeComponent();
			
			// Insert code required on object creation below this point.
		}
	}
}