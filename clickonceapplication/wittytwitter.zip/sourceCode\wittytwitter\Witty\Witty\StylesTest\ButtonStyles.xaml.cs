
namespace Witty.StylesTest
{
    /// <summary>
    /// Interaction logic for ButtonStyles.xaml
    /// </summary>

    public partial class ButtonStyles : System.Windows.Window
    {

        public ButtonStyles()
        {
            InitializeComponent();
        }

    }
}