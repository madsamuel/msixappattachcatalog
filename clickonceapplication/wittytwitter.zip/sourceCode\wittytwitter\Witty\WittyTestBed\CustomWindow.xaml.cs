﻿using FluidKit.Controls;

namespace WittyTestBed
{
    /// <summary>
    /// Interaction logic for CustomWindow.xaml
    /// </summary>
    public partial class CustomWindow : GlassWindow
    {
        public CustomWindow()
        {
            InitializeComponent();
        }
    }
}
