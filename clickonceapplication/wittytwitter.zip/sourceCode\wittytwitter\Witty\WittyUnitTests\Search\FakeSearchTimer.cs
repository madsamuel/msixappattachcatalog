using System;
using Witty.Controls.Search;

namespace WittyUnitTests.Search
{
    public class FakeSearchTimer : ISearchTimer
    {
        public void RaiseTickEvent()
        {
            var handler = Tick;
            if (handler != null)
            {
                handler(this, new EventArgs());
            }
        }

        public event EventHandler<EventArgs> Tick;
    }
}
